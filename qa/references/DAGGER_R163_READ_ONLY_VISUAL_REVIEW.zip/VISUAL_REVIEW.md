# Dagger Country Club — proposed R163 visual baseline recovery

Status: FOR USER VISUAL CONFIRMATION. No application code changed. No deployment. No backend data read or written.

## Capture method
Untouched supplied Dagger-R163-Ledger-Cleanup.zip extracted source, Chromium 153, fresh temporary browser context, 390 CSS pixels wide, device scale factor 1. Navigation and the existing Use starter profile button were used; no DOM, stylesheet, layout, or application logic was patched. All original source file hashes were checked before and after; unchanged. HTML SHA-256: d47e793daa6dfc72f2cf15f8bc6b6c596872f9cd5f35bbdc0dfbfb5021b023b7.

The five numbered main screenshots use a tall mobile-width viewport matching each page's full height, so the existing fixed navigation sits at the image bottom and does not cover page content. The additional *-844-viewport-fullpage.png screenshots retain a conventional 390x844 viewport, including its fixed navigation overlay. Both are browser screenshots, not retouched images. The five-tab review sheet only scales copies for convenience.

Original local modules executed, including dynamic account and Money Room UI. The matching official Firebase 11.10.0 browser SDK files were supplied from the firebase@11.10.0 npm distribution at the original SDK request URLs because the CDN failed in this environment; no SDK or app code was modified. Every request outside local source and those SDK files was aborted. An automatic anonymous-auth POST was intercepted and blocked before network transmission. No account creation, login, AI call, or database access was allowed. Service workers were blocked.

## Verified observations
- All five tabs rendered with no horizontal overflow at 390 pixels.
- One original circular seal is visible per selected tab, outside its main cards. The corresponding footer is a direct child of the content container.
- No global membership banner appears beneath the masthead. The membership status text inside the Clubhouse account form is a separate existing element; it is not the rejected banner.
- Grounds: compact Competition Archive, Rules & Formats, House Ghost below the multiplayer card, and original circular seal outside the cards.
- Ledger: + New Bet is the sole visible form entry; wager counters, Outstanding Debts, Archives, Money Room, and Club Record are present. Wins, Losses, Archived, Member Net display zero/$0.00 for this fresh context. Club Record was genuinely visible with no visibility flags removed by the test harness. No R177 patch applied.
- The supplemental screenshot shows the existing wager form opened through + New Bet. No ticket was issued or bet saved. Field hints are supplied application placeholders, not new records.
- The observed R175 missing-record regression was not reproduced in this fresh R163 run. That does not establish a repair for saved-state, device, or initialization timing variants.

## Comparison with supplied references
R163_LEDGER_320.png and R163_LEDGER_390.png show the same Ticket Window, single + New Bet entry, three wager summary boxes, Outstanding Debts card, and Archives styling. The supplied screenshots are cropped (actual image sizes 254x979 and 324x933), contain a sample open ticket, and omit Club Record and footer, so they do not permit a full-page pixel-equality claim. Fresh empty-state counters and collapsed Archives differ because no saved wager was loaded.

IMG_8454.png shows the accepted compact Grounds archive spacing, House Ghost below it, and original seal outside the card. Those structural details are present in the recovered Grounds capture. IMG_8453 and IMG_8455 are evidence of R175 defects and were not accepted as full baseline references. The rejected full-width membership banner is absent, and Club Record is visible here.

R159–R163 documentation supports the original seal, outside-card footers on all five tabs, and the single Ledger form entry. No complete supplied approved full-page reference exists for Caddy, Equipment Room, or Clubhouse. The captures recover the package's design; approval must come from the user.

## Environmental limits — excluded from design approval
The R163 ZIP does not contain profile.json, though the app requests it. The original request fails and its JSON parse raises an error. Choosing the existing starter option dismisses onboarding, but the bag remains empty. No replacement profile or invented shot data was supplied. Equipment's empty state is visible; populated clubs and real dispersion are not verified.

Money Room displays auth/network-request-failed because outbound authentication is deliberately blocked. Clubhouse displays its signed-out status and existing sign-in form. These service-dependent messages are capture conditions, not proposed permanent design changes. Authenticated account appearance, saved wagers/competitions, archive record detail, real scoring data, AI replies, and two-device sync are unverified.

## User decision required
Confirm whether the five numbered captures match the final approved interface, especially the Caddy arrangement, Grounds spacing, Club Record position, Equipment empty state, Clubhouse account layout, and five footer seals. Service errors and missing profile content are excluded from visual approval. No development should infer approval from these recovered images alone.
