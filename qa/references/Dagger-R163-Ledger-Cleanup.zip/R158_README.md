# R158 — Header consistency (staging only)
- Grounds title is sentence case, `The Grounds`.
- Grounds tagline: `Choose your game. Own the round.`
- Clubhouse tagline: `Your club. Your people. Your caddies.`
- No modifications to game logic, Firebase configuration, original imagery, or production.
- Deploy from this extracted folder only: `npx firebase-tools deploy --only hosting --project dagger-country-club-staging`.
- Verify all five tab headers on phone after deployment; browser rendering has not been tested for this patch.
