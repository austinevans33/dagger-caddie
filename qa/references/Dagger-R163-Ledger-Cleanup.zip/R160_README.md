# R160 — Clubhouse heritage seal finishing polish

- Removed the redundant “As It Lies” caption beneath the Clubhouse seal. The original approved seal already contains the words.
- Used CSS `mix-blend-mode: lighten` on the Clubhouse seal only. Its dark green raster backing blends with the actual Clubhouse forest green without modifying the approved artwork.
- Archive seal and its label are unchanged.
- No Firebase configuration, backend, scoring or wager logic changes.
- Staging hosting package only. Production is not cleared.

Run from this folder: `npx firebase-tools deploy --only hosting --project dagger-country-club-staging`.
