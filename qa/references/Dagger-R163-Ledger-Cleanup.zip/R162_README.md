# R162 — Consistent seal footers

- All five seals now sit at the bottom of the tab, outside the tab’s main content cards.
- Clubhouse existing seal is MOVED, not duplicated.
- Grounds footer is guaranteed independently of game-card ordering.
- Each seal participates in existing `switchTab()` tab visibility via `data-tab`.
- Original seal PNG, scores, Firebase, AI, and wagering logic are untouched.
- Staging-only. Production not approved.

Deploy from this extracted folder: `npx firebase-tools deploy --only hosting --project dagger-country-club-staging`.
