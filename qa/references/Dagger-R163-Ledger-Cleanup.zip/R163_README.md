# R163 — Ledger single action

Fix: On The Ledger, the gold **+ New Bet** button is now the only visible entry point for the new-ticket form. The redundant **ISSUE A NEW TICKET** accordion header is visually hidden, while its form remains intact and usable.

Clicking + New Bet opens and focuses the form; clicking **Close Bet Form** collapses it. The control exposes `aria-controls` and `aria-expanded`. Saving a ticket closes the form and restores + New Bet.

This is a visual and interaction change only; no Firebase, wager arithmetic, persisted data, or brand assets changed.

**Deploy only to staging**, from this extracted folder: `npx firebase-tools deploy --only hosting --project dagger-country-club-staging`. Production is not authorized.
